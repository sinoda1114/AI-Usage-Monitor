/** Collects usage metrics only; no on-page UI (does not load i18n.js). */
const CONTENT_BUILD = "0.5.15";

let collectorAlive = true;
let observer = null;

if (globalThis.__aiUsageContentBuild && globalThis.__aiUsageContentBuild !== CONTENT_BUILD) {
  console.info(
    "[AI Usage Monitor] Extension was updated. Reload this tab (F5) to clear the old collector."
  );
}
globalThis.__aiUsageContentBuild = CONTENT_BUILD;

window.addEventListener("unhandledrejection", (event) => {
  const reason = String(event.reason?.message || event.reason || "");
  if (reason.includes("A listener indicated an asynchronous response by returning true")) {
    event.preventDefault();
    return;
  }
  if (!reason.includes("Extension context invalidated")) return;
  event.preventDefault();
  stopCollector("unhandled rejection: context invalidated");
});

function isExtensionContextAlive() {
  try {
    return Boolean(chrome?.runtime?.id);
  } catch {
    return false;
  }
}

function isContextInvalidatedError(error) {
  const message = String(error?.message || error || "");
  return (
    message.includes("Extension context invalidated") ||
    message.includes("Receiving end does not exist") ||
    message.includes("Cannot read properties of undefined (reading 'sendMessage')") ||
    message.includes("Cannot read properties of undefined (reading 'id')") ||
    message.includes("Cannot read properties of undefined (reading 'local')")
  );
}

function stopCollector(reason) {
  if (!collectorAlive) return;
  collectorAlive = false;
  detachObserver();
  console.info("[AI Usage Monitor] stopped collector loop:", reason);
}

function isDevinUsagePath(pathname) {
  const p = (pathname || "").replace(/\/+$/, "") || "";
  if (/\/settings\/usage-and-limits$/i.test(p)) return true;
  if (/\/settings\/usage$/i.test(p)) return true;
  if (/\/settings\/[^/]*usage/i.test(p)) return true;
  if (/^\/org\/[^/]+\/usage(?:-and-limits)?$/i.test(p)) return true;
  return false;
}

function isDevinHost(hostname) {
  return hostname === "app.devin.ai" || hostname.endsWith(".devin.ai");
}

function isClaudeUsagePage(href) {
  try {
    const u = new URL(href);
    if (u.hostname !== "claude.ai") return false;
    if (/\/settings\/usage/i.test(u.pathname)) return true;
    if (/settings\/usage/i.test(u.hash || "")) return true;
    return false;
  } catch {
    return false;
  }
}

async function resolveProvider() {
  const href = window.location.href;
  try {
    const u = new URL(href);

    if (u.hostname.includes("cursor.com")) return "cursor";
    if (href.includes("chatgpt.com/codex")) return "codex";
    if (isClaudeUsagePage(href)) return "claude";

    if (!isDevinHost(u.hostname)) return null;

    const path = decodeURIComponent((u.pathname || "").replace(/\/+$/, "") || "");
    const pathSlug = path.match(/^\/org\/([a-zA-Z0-9_-]+)/)?.[1];

    if (pathSlug && isDevinUsagePath(path)) return "devin";

    if (!isExtensionContextAlive()) return null;
    const { devinOrgSlug } = await chrome.storage.local.get("devinOrgSlug");
    const configured = String(devinOrgSlug ?? "").trim();
    const slug = configured || pathSlug;
    if (!slug) return null;

    const seg = `/org/${slug}`;

    const authLike = /\/auth|\/login|\/signin|\/signup/i.test(path);
    if (authLike) {
      const keys = ["redirect", "next", "returnUrl", "return_url"];
      for (const key of keys) {
        const raw = u.searchParams.get(key);
        if (!raw) continue;
        try {
          const dec = decodeURIComponent(raw);
          if (dec.includes(seg)) return "devin";
        } catch {
          if (raw.includes(slug)) return "devin";
        }
      }
      try {
        const full = decodeURIComponent(href);
        if (full.includes(seg)) return "devin";
      } catch {
        if (href.includes(slug)) return "devin";
      }
    }
  } catch {
    return null;
  }

  return null;
}

function compactText() {
  const parts = [];
  const seen = new WeakSet();

  function walk(node) {
    if (!node || seen.has(node)) return;
    if (node.nodeType === Node.TEXT_NODE) {
      const value = node.textContent?.replace(/\s+/g, " ").trim();
      if (value) parts.push(value);
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;

    const el = node;
    seen.add(el);
    if (el.shadowRoot) walk(el.shadowRoot);
    for (const child of el.childNodes) walk(child);
  }

  if (document.body) walk(document.body);
  const joined = parts.join(" ").replace(/\s+/g, " ").trim();
  if (joined) return joined;
  return (document.body?.innerText ?? "").replace(/\s+/g, " ").trim();
}

function findReset(text) {
  const resetsIn = text.match(/Resets\s+in\s+([^\n.,;|]{2,40})/i)?.[1]?.trim();
  if (resetsIn) return resetsIn;

  const resetsOn =
    text.match(/Resets\s+on\s+(\d{1,2}\s*月\s*\d{1,2}\s*日(?:\s*\([^)]*\))?)/i)?.[1]?.trim() ??
    text.match(/Resets\s+on\s+([A-Za-z]{3,9}\s+\d{1,2}(?:\s*\([^)]*\))?)/i)?.[1]?.trim() ??
    text.match(/Resets\s+on\s+(\d{1,2}\/\d{1,2}(?:\/\d{2,4})?(?:\s*\([^)]*\))?)/i)?.[1]?.trim();
  if (resetsOn) return resetsOn;

  const relative =
    text.match(/(\d+)\s*(?:days?\s*later|日後)/i) ?? text.match(/あと\s*(\d+)\s*日/);
  if (relative) return `${relative[1]} days`;

  return undefined;
}

/** Cursor spending: avoid matching "14 日間の無料トライアル" as reset. */
function findCursorReset(text) {
  return (
    text.match(/Resets\s+on\s+(\d{1,2}\s*月\s*\d{1,2}\s*日(?:\s*\([^)]*\))?)/i)?.[1]?.trim() ??
    text.match(/Resets\s+on\s+([A-Za-z]{3,9}\s+\d{1,2}(?:\s*\([^)]*\))?)/i)?.[1]?.trim() ??
    text.match(/Resets\s+on\s+(\d{1,2}\/\d{1,2}(?:\/\d{2,4})?(?:\s*\([^)]*\))?)/i)?.[1]?.trim() ??
    text.match(/Resets\s+in\s+([^\n.,;|]{2,36})/i)?.[1]?.trim()
  );
}

function metricId(provider, label) {
  if (provider === "codex" && /5\s*時間|5[-\s]*hour/i.test(label)) return "codex-five-hour";
  if (provider === "codex" && /週あたり|週間|weekly/i.test(label)) return "codex-weekly";
  if (provider === "claude" && /現在のセッション|current session/i.test(label)) return "claude-current-session";
  if (provider === "claude" && /週間制限|weekly|すべてのモデル/i.test(label)) return "claude-weekly";
  if (provider === "claude" && /(?:Claude\s*)?Sonnet(?:\s+[^%\s]+){0,4}|ソネット(?:\s+[^%\s]+){0,4}/i.test(label)) return "claude-sonnet";
  if (provider === "claude" && /ルーティン|routine/i.test(label)) return "claude-routines";
  if (provider === "claude" && /追加使用量|extra/i.test(label)) return "claude-extra";
  if (provider === "claude" && /claude\s*design/i.test(label)) return "claude-design";
  if (provider === "devin" && /daily\s*quota/i.test(label)) return "devin-daily-quota";
  if (provider === "devin" && /weekly\s*quota/i.test(label)) return "devin-weekly-quota";
  const slug = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  return `${provider}-${slug || "usage"}`;
}

function pushMetric(metrics, provider, label, usedPercentage, resetAt, detail) {
  if (!Number.isFinite(usedPercentage)) return;
  const cleanLabel = label
    .replace(/used|使用済み|利用済み/gi, "")
    .replace(/[:：|/]+$/g, "")
    .trim()
    .slice(-48) || "Usage";
  const id = metricId(provider, cleanLabel);
  if (metrics.some((metric) => metric.id === id)) return;
  metrics.push({
    id,
    label: cleanLabel,
    usedPercentage: Math.max(0, Math.min(100, Math.round(usedPercentage))),
    resetAt: resetAt === null ? undefined : resetAt,
    detail,
  });
}

function codexUsedPercentage(value, qualifier) {
  const q = String(qualifier || "").toLowerCase();
  return q === "残り" || q === "remaining" ? 100 - value : value;
}

function metricsFromBars(provider) {
  const metrics = [];
  const text = compactText();
  const resetAt = findReset(text);

  if (provider === "cursor") {
    const cursorReset = findCursorReset(text);
    const total = text.match(/(?:Included in Pro\s+)?Total\s+(\d{1,3})\s*%/i);
    if (total) pushMetric(metrics, provider, "Total", Number(total[1]), cursorReset);

    const firstParty =
      text.match(/First[-\s]Party\s+Models\s+(\d{1,3})\s*%/i) ??
      text.match(/(\d{1,3})\s*%\s*First[-\s]Party\s+Models/i);
    if (firstParty) {
      const value = firstParty[1];
      pushMetric(metrics, provider, "First-Party Models", Number(value), cursorReset);
    }

    const auto =
      text.match(/Auto\s*\+\s*Composer\s+(\d{1,3})\s*%/i) ??
      text.match(/(\d{1,3})\s*%\s*Auto(?:\s+and|\s|$)/i);
    if (auto) pushMetric(metrics, provider, "Auto + Composer", Number(auto[1]), cursorReset);

    const api =
      text.match(/API\s+(\d{1,3})\s*%/i) ??
      text.match(/(\d{1,3})\s*%\s*API\s+used/i);
    if (api) pushMetric(metrics, provider, "API", Number(api[1]), cursorReset);

    if (metrics.length > 0) return metrics;
  }

  if (provider === "codex") {
    const fiveHour =
      text.match(
        /5\s*時間の使用制限\s+(\d{1,3})\s*%\s*(残り|使用済み)?[^リ]*(?:リセット[:：]\s*((?:\d{4}\/\d{2}\/\d{2}\s+)?\d{1,2}:\d{2}))?/i
      ) ??
      text.match(
        /5[-\s]*hour(?:ly)?\s+(?:usage\s+)?limit[^0-9]{0,48}(\d{1,3})\s*%\s*(remaining|used)?[^.]{0,48}(?:reset(?:s)?(?:\s+on)?[:：]?\s*([^\s,.|]+(?:\s+[^\s,.|]+)?))?/i
      );
    if (fiveHour) {
      const label = /5\s*時間/.test(text) ? "5時間の使用制限" : "5-hour usage limit";
      pushMetric(
        metrics,
        provider,
        label,
        codexUsedPercentage(Number(fiveHour[1]), fiveHour[2]),
        fiveHour[3] ?? resetAt
      );
    }

    const weekly =
      text.match(
        /週(?:あたりの使用制限|間利用上限|間の使用制限)\s+(\d{1,3})\s*%\s*(残り|使用済み)?[^リ]*(?:リセット[:：]\s*((?:\d{4}\/\d{2}\/\d{2}\s+)?\d{1,2}:\d{2}))?/i
      ) ??
      text.match(
        /weekly\s+(?:usage\s+)?limit[^0-9]{0,48}(\d{1,3})\s*%\s*(remaining|used)?[^.]{0,48}(?:reset(?:s)?(?:\s+on)?[:：]?\s*([^\s,.|]+(?:\s+[^\s,.|]+)?))?/i
      );
    if (weekly) {
      const label = /週間利用上限/.test(text)
        ? "週間利用上限"
        : /週間の使用制限/.test(text)
          ? "週間の使用制限"
          : /週あたり/.test(text)
            ? "週あたりの使用制限"
            : "Weekly usage limit";
      pushMetric(
        metrics,
        provider,
        label,
        codexUsedPercentage(Number(weekly[1]), weekly[2]),
        weekly[3] ?? resetAt
      );
    }

    const credits =
      text.match(/残りのクレジット\s+(\d+(?:\.\d+)?)/) ??
      text.match(/(?:credits?\s+)?remaining[^0-9]{0,24}(\d+(?:\.\d+)?)/i);
    if (credits) {
      const label = /残りのクレジット/.test(text) ? "残りのクレジット" : "Credits remaining";
      metrics.push({
        id: "codex-credits",
        label,
        usedPercentage: null,
        detail: credits[1],
      });
    }

    if (metrics.length > 0) return metrics;
  }

  if (provider === "claude") {
    const current = parseClaudeSection(text, [/現在のセッション/, /current session/i]);
    if (current) pushMetric(metrics, provider, "現在のセッション", current.usedPercentage, current.resetAt ?? null);

    // Claude now places a promotion notice between the weekly heading and the
    // actual "all models" meter. Keep the section wide enough to reach that
    // meter; parseClaudeMetricSlice only accepts usage percentages, so notice
    // percentages such as "50% higher" are ignored.
    const weekly = parseClaudeSection(text, [/週間制限/, /すべてのモデル/, /all models/i], 900);
    if (weekly) pushMetric(metrics, provider, "週間制限", weekly.usedPercentage, weekly.resetAt ?? null);

    const model = parseClaudeNamedModelSection(text) ?? parseClaudeNamedModelElementSection();
    if (model) {
      const label = model.name === "Sonnet" ? "Sonnetのみ" : model.name;
      pushMetric(metrics, provider, label, model.usedPercentage, model.resetAt ?? null);
    }

    const claudeDesign = parseClaudeSection(text, [/Claude\s*Design/i]);
    if (claudeDesign) pushMetric(metrics, provider, "Claude Design", claudeDesign.usedPercentage, claudeDesign.resetAt ?? null);

    const routines =
      text.match(/(?:ルーティン実行数|routine runs?)[^0-9]{0,80}(\d+)\s*\/\s*(\d+)/i) ??
      text.match(/(?:included\s+)?routine\s+runs?[^0-9]{0,80}(\d+)\s*\/\s*(\d+)/i);
    if (routines) {
      const used = Number(routines[1]);
      const limit = Number(routines[2]);
      const label = /ルーティン/.test(text)
        ? "1日の含まれるルーティン実行数"
        : "Included routine runs per day";
      pushMetric(
        metrics,
        provider,
        label,
        limit > 0 ? (used / limit) * 100 : 0,
        /毎日|daily/i.test(text) ? "Daily" : "毎日",
        `${used} / ${limit}`
      );
    }

    const extra = parseClaudeSection(text, [/追加使用量/, /extra usage/i]);
    if (extra) pushMetric(metrics, provider, "追加使用量", extra.usedPercentage, extra.resetAt ?? null);

    if (metrics.length > 0) return metrics;
  }

  if (provider === "devin") {
    const dailySection = parseDevinQuotaSection(text, "daily");
    if (dailySection) {
      pushMetric(metrics, provider, "Daily quota", dailySection.usedPercentage, dailySection.resetAt);
    }

    const weeklySection = parseDevinQuotaSection(text, "weekly");
    if (weeklySection) {
      pushMetric(metrics, provider, "Weekly quota", weeklySection.usedPercentage, weeklySection.resetAt);
    }

    const acu =
      text.match(/\b(\d+)\s*\/\s*(\d+)\s+ACUs?\b/i) ??
      text.match(/\b(\d+)\s*\/\s*(\d+)\s+ACU\b/i) ??
      text.match(/\bACUs?\s*[:\s]+\s*(\d+)\s*\/\s*(\d+)/i);
    if (acu && Number(acu[2]) > 0) {
      pushMetric(
        metrics,
        provider,
        "ACU",
        Math.min(100, (Number(acu[1]) / Number(acu[2])) * 100),
        dailySection?.resetAt ?? weeklySection?.resetAt ?? resetAt,
        `${acu[1]} / ${acu[2]}`
      );
    }

    const onDemandBal = text.match(/Remaining\s+balance\s*:?\s*\$?\s*([\-\d.,]+)/i);
    if (onDemandBal && !metrics.some((m) => m.id === "devin-on-demand-balance")) {
      metrics.push({
        id: "devin-on-demand-balance",
        label: "On-demand balance",
        usedPercentage: null,
        detail: `$${onDemandBal[1].replace(/,/g, "")}`,
      });
    }

    const creditsLine =
      text.match(/(?:credits?\s+remaining|残り(?:の)?クレジット)[^\d]{0,24}(\d[\d,.]*)/i) ??
      text.match(/(?:クレジット|残高)[^\d]{0,12}(\d[\d,.]*)/);
    if (creditsLine && !metrics.some((m) => m.id === "devin-credits")) {
      metrics.push({
        id: "devin-credits",
        label: "Credits",
        usedPercentage: null,
        detail: creditsLine[1].replace(/,/g, ""),
      });
    }
    return metrics;
  }

  const candidates = [...document.querySelectorAll("body *")]
    .filter((node) => node.childElementCount <= 3)
    .map((node) => node.innerText?.replace(/\s+/g, " ").trim())
    .filter((value) => Boolean(value) && value.length < 120 && !/[{}[\]<>]/.test(value));

  for (const value of candidates) {
    const percent = value.match(/(\d{1,3})\s*%/);
    if (!percent) continue;
    const usedPercentage = Math.min(100, Number(percent[1]));
    const label =
      value
        .replace(/\d{1,3}\s*%.*/, "")
        .replace(/used|使用済み|利用済み/gi, "")
        .trim() || "Usage";

    pushMetric(metrics, provider, label, usedPercentage, resetAt);
  }

  return metrics.slice(0, 10);
}

/**
 * Claude: slice from a section heading to its own percentage and read the reset
 * text nearest that percentage. Claude often renders reset text before the bar
 * percentage, so prefer text before the percentage to avoid bleeding from the
 * next sibling section.
 */

function parseClaudeMetricSlice(slice) {
  const pct = slice.match(/(\d{1,3})\s*%\s*(?:使用済み|used|使用)/i);
  if (!pct) return null;

  const before = slice.slice(0, pct.index);
  const after = slice.slice(pct.index + pct[0].length).split(/\d{1,3}\s*%/)[0];
  return { usedPercentage: Number(pct[1]), resetAt: resetFromSection(before) ?? resetFromSection(after) };
}

function parseClaudeElementSection(patterns) {
  const candidates = [...document.querySelectorAll("body *")]
    .map((node) => node.innerText?.replace(/\s+/g, " ").trim())
    .filter((value) => Boolean(value) && value.length <= 1200)
    .filter((value) => patterns.some((pattern) => pattern.test(value)))
    .sort((a, b) => a.length - b.length);

  for (const value of candidates) {
    let idx = -1;
    for (const pattern of patterns) {
      const found = value.search(pattern);
      if (found >= 0 && (idx < 0 || found < idx)) idx = found;
    }
    if (idx < 0) continue;
    const parsed = parseClaudeMetricSlice(value.slice(idx));
    if (parsed) return parsed;
  }
  return null;
}

const CLAUDE_MODEL_PATTERNS = [
  { name: "Fable", pattern: /\bFable\b/i },
  { name: "Sonnet", pattern: /(?:Claude\s*)?Sonnet(?:\s+\d+(?:\.\d+)?)?/i },
  { name: "Opus", pattern: /(?:Claude\s*)?Opus(?:\s+\d+(?:\.\d+)?)?/i },
  { name: "Haiku", pattern: /(?:Claude\s*)?Haiku(?:\s+\d+(?:\.\d+)?)?/i },
  { name: "ソネット", pattern: /ソネット/i },
];

function parseClaudeNamedModelSlice(value, model, startAt = 0) {
  const idx = value.search(model.pattern);
  if (idx < startAt) return null;
  const parsed = parseClaudeMetricSlice(value.slice(idx, idx + 500));
  if (!parsed) return null;
  return { name: model.name === "ソネット" ? "Sonnet" : model.name, ...parsed };
}

function parseClaudeNamedModelSection(text) {
  const weeklyIdx = text.search(/週間制限|すべてのモデル|weekly|all models/i);
  const startAt = weeklyIdx >= 0 ? weeklyIdx : 0;
  const candidates = [];
  for (const model of CLAUDE_MODEL_PATTERNS) {
    const parsed = parseClaudeNamedModelSlice(text, model, startAt);
    if (parsed) candidates.push({ index: text.search(model.pattern), parsed });
  }
  candidates.sort((a, b) => a.index - b.index);
  return candidates[0]?.parsed ?? null;
}

function parseClaudeNamedModelElementSection() {
  const candidates = [...document.querySelectorAll("body *")]
    .map((node) => node.innerText?.replace(/\s+/g, " ").trim())
    .filter((value) => Boolean(value) && value.length <= 1200);
  for (const value of candidates.sort((a, b) => a.length - b.length)) {
    for (const model of CLAUDE_MODEL_PATTERNS) {
      const parsed = parseClaudeNamedModelSlice(value, model);
      if (parsed) return parsed;
    }
  }
  return null;
}

function parseClaudeSection(text, patterns, maxLen = 260) {
  let idx = -1;
  for (const pattern of patterns) {
    const found = text.search(pattern);
    if (found >= 0 && (idx < 0 || found < idx)) idx = found;
  }
  if (idx < 0) return null;

  const slice = text.slice(idx, idx + maxLen);
  return parseClaudeMetricSlice(slice);
}

function resetFromSection(section) {
  if (!section) return undefined;
  return (
    section.match(/(\d{1,2}\s*月\s*\d{1,2}\s*日(?:\s*\([^)]*\))?\s*にリセット)/)?.[1]?.trim() ??
    section.match(/(\d+\s*時間\s*\d+\s*分後にリセット)/)?.[1]?.trim() ??
    section.match(/(\d+\s*時間後にリセット)/)?.[1]?.trim() ??
    section.match(/(\d+\s*分後にリセット)/)?.[1]?.trim() ??
    section.match(/(\d+\s*hours?\s*\d+\s*minutes?\s*later)/i)?.[1]?.trim() ??
    section.match(/(\d+\s*hours?\s*later)/i)?.[1]?.trim() ??
    section.match(/(\d+\s*minutes?\s*later)/i)?.[1]?.trim() ??
    section.match(/(\d{1,2}:\d{2}\s*\([^)]+\)\s*にリセット)/)?.[1]?.trim() ??
    section.match(/([A-Z][a-z]{2}\s+\d{1,2}\s*にリセット)/)?.[1]?.trim() ??
    section.match(/([A-Z][a-z]{2}\s+\d{1,2})/)?.[1]?.trim() ??
    section.match(/([0-9]{4}\/[0-9]{2}\/[0-9]{2}\s+[0-9]{1,2}:[0-9]{2})/)?.[1]?.trim()
  );
}

/** Devin: parse quota block so reset text does not bleed across Daily / Weekly. */
function parseDevinQuotaSection(text, kind) {
  const patterns =
    kind === "daily"
      ? [/Daily\s+quota/i, /日次\s*(?:クォータ|割当)?/i]
      : [/Weekly\s+quota/i, /週次\s*(?:クォータ|割当)?/i];
  let idx = -1;
  for (const pattern of patterns) {
    const found = text.search(pattern);
    if (found >= 0 && (idx < 0 || found < idx)) idx = found;
  }
  if (idx < 0) return null;

  const slice = text.slice(idx, idx + 240);
  const pctMatch =
    slice.match(/(\d{1,3})\s*%\s*used\b/i) ??
    slice.match(/(\d{1,3})\s*%\s*(?:使用|利用)/i) ??
    slice.match(/used\s*:?\s*(\d{1,3})\s*%/i) ??
    slice.match(/(?:使用|利用)\s*:?\s*(\d{1,3})\s*%/i);
  if (!pctMatch) return null;

  const resetAt = slice.match(/Resets\s+in\s+(\d+\s+(?:minutes?|hours?|days?))/i)?.[1]?.trim();
  return { usedPercentage: Number(pctMatch[1]), resetAt };
}

function providerName(provider) {
  if (provider === "cursor") return "Cursor";
  if (provider === "codex") return "Codex";
  if (provider === "devin") return "Devin";
  return "Claude";
}

function detachObserver() {
  observer?.disconnect();
  observer = null;
}

function attachObserver() {
  if (observer || !document.body) return;
  observer = new MutationObserver(scheduleSend);
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
}

async function syncCollectorForPage() {
  if (!collectorAlive) return false;
  const provider = await resolveProvider();
  if (!provider) {
    detachObserver();
    return false;
  }
  attachObserver();
  return true;
}

/** Normalize Claude utilization floats that may be 0–1 or 0–100. */
function normalizeClaudeUtilization(value) {
  if (value == null || value === "") return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  // Prefer 0–100 percent scale (API often returns 1 for 1%).
  // Only treat strict fractions (0, 1) as 0–1.
  if (n > 0 && n < 1) return Math.round(n * 100);
  return Math.max(0, Math.min(100, Math.round(n)));
}

function formatClaudeResetAt(iso) {
  if (!iso) return undefined;
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return String(iso);
  const ms = t - Date.now();
  if (ms <= 0) {
    try {
      return new Date(t).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
    } catch {
      return String(iso);
    }
  }
  const minutes = Math.round(ms / 60000);
  if (minutes < 60) return `${minutes} minutes later`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours < 48) {
    return mins > 0 ? `${hours} hours ${mins} minutes later` : `${hours} hours later`;
  }
  try {
    return new Date(t).toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return String(iso);
  }
}

function pushClaudeWindowMetric(metrics, label, window) {
  if (!window || typeof window !== "object") return;
  const usedPercentage = normalizeClaudeUtilization(window.utilization);
  if (usedPercentage == null) return;
  pushMetric(metrics, "claude", label, usedPercentage, formatClaudeResetAt(window.resets_at) ?? null);
}

/** Map Claude settings/usage JSON → existing popup metric ids. */
function mapClaudeUsageJson(data) {
  const metrics = [];
  if (!data || typeof data !== "object") return metrics;

  pushClaudeWindowMetric(metrics, "現在のセッション", data.five_hour);
  pushClaudeWindowMetric(metrics, "週間制限", data.seven_day);
  pushClaudeWindowMetric(metrics, "Sonnetのみ", data.seven_day_sonnet);
  pushClaudeWindowMetric(metrics, "Opus", data.seven_day_opus);
  pushClaudeWindowMetric(metrics, "Fable", data.seven_day_fable ?? data.seven_day_omelette);
  pushClaudeWindowMetric(metrics, "Cowork", data.seven_day_cowork);
  pushClaudeWindowMetric(metrics, "OAuth apps", data.seven_day_oauth_apps);

  const extra = data.extra_usage;
  if (extra && typeof extra === "object") {
    const usedPercentage = normalizeClaudeUtilization(extra.utilization);
    if (usedPercentage != null && extra.is_enabled !== false) {
      const detail =
        extra.used_credits != null && extra.monthly_limit != null
          ? `$${extra.used_credits} / $${extra.monthly_limit}`
          : undefined;
      pushMetric(metrics, "claude", "追加使用量", usedPercentage, formatClaudeResetAt(extra.resets_at) ?? null, detail);
    }
  }

  return metrics;
}

function pickClaudeOrgId(payload) {
  const list = Array.isArray(payload)
    ? payload
    : payload?.organizations ?? payload?.data ?? payload?.orgs ?? [];
  if (!Array.isArray(list) || list.length === 0) {
    if (payload && typeof payload === "object") {
      return payload.uuid ?? payload.id ?? payload.organization_uuid ?? null;
    }
    return null;
  }
  const preferred =
    list.find((org) => org?.uuid || org?.id || org?.organization_uuid) ?? list[0];
  return preferred?.uuid ?? preferred?.id ?? preferred?.organization_uuid ?? null;
}

async function fetchClaudeJson(url) {
  const response = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: {
      Accept: "application/json",
      Referer: "https://claude.ai/settings/usage",
    },
  });
  if (!response.ok) {
    throw new Error(`Claude API ${response.status} for ${url}`);
  }
  return response.json();
}

async function fetchClaudeMetricsFromApi() {
  const orgs = await fetchClaudeJson("https://claude.ai/api/organizations");
  const orgId = pickClaudeOrgId(orgs);
  if (!orgId) return [];
  const usage = await fetchClaudeJson(
    `https://claude.ai/api/organizations/${encodeURIComponent(orgId)}/usage`
  );
  return mapClaudeUsageJson(usage);
}

async function collectClaudeMetrics() {
  try {
    const apiMetrics = await fetchClaudeMetricsFromApi();
    if (apiMetrics.length > 0) {
      const domMetrics = metricsFromBars("claude");
      for (const metric of domMetrics) {
        // Supplement fields the usage JSON often omits (routines, design, named models).
        if (!apiMetrics.some((entry) => entry.id === metric.id)) {
          apiMetrics.push(metric);
        }
      }
      return { metrics: apiMetrics, source: "claude-api" };
    }
  } catch (error) {
    console.warn("[AI Usage Monitor] Claude API collect failed; falling back to DOM", error);
  }
  return { metrics: metricsFromBars("claude"), source: "web-collector" };
}

async function sendSnapshot() {
  if (!collectorAlive) return;
  if (!isExtensionContextAlive()) {
    stopCollector("extension context invalidated");
    return;
  }
  const provider = await resolveProvider();
  if (!provider) {
    detachObserver();
    return;
  }
  attachObserver();

  const collected =
    provider === "claude"
      ? await collectClaudeMetrics()
      : { metrics: metricsFromBars(provider), source: "web-collector" };
  const metrics = collected.metrics;
  const snapshot = {
    provider,
    name: providerName(provider),
    source: collected.source,
    url: window.location.href,
    title: document.title,
    collectedAt: new Date().toISOString(),
    metrics,
    status: metrics.length > 0 ? "ok" : "no-metrics",
    diagnostic:
      metrics.length > 0
        ? `${metrics.length} metric(s) via ${collected.source} from ${document.title}`
        : `Collector ran on ${document.title}, but no metric matched`,
  };

  if (!isExtensionContextAlive()) {
    stopCollector("extension context invalidated");
    return;
  }

  try {
    const result = await chrome.runtime.sendMessage({
      type: "AI_USAGE_SNAPSHOT",
      snapshot,
    });
    if (!result?.ok) {
      console.warn("[AI Usage Monitor] snapshot not saved", result);
      return;
    }
  } catch (error) {
    if (isContextInvalidatedError(error) || !isExtensionContextAlive()) {
      stopCollector("snapshot message rejected: context invalidated");
      return;
    }
    console.warn("[AI Usage Monitor] snapshot send failed", error);
    return;
  }

  if (!isExtensionContextAlive()) {
    stopCollector("extension context invalidated");
    return;
  }

  try {
    await chrome.runtime.sendMessage({
      type: "AI_USAGE_COLLECTED",
      provider,
      metricsCount: metrics.length,
      url: window.location.href,
    });
  } catch (error) {
    if (isContextInvalidatedError(error) || !isExtensionContextAlive()) {
      stopCollector("collected message rejected: context invalidated");
    }
  }
}

let timer = 0;
function scheduleSend() {
  if (!collectorAlive) return;
  if (!isExtensionContextAlive()) {
    stopCollector("extension context invalidated");
    return;
  }
  window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    void sendSnapshot().catch((error) => {
      if (isContextInvalidatedError(error) || !isExtensionContextAlive()) {
        stopCollector("sendSnapshot rejected: context invalidated");
        return;
      }
      console.warn("[AI Usage Monitor] sendSnapshot failed", error);
    });
  }, 1200);
}

function scheduleDevinRetries() {
  if (!isDevinHost(window.location.hostname) || !isDevinUsagePath(window.location.pathname || "")) return;
  for (const delay of [400, 1200, 3000, 6000]) {
    window.setTimeout(() => scheduleSend(), delay);
  }
}

function scheduleCursorRetries(provider) {
  if (provider !== "cursor") return;
  for (const delay of [800, 2000, 5000, 10000]) {
    window.setTimeout(() => scheduleSend(), delay);
  }
}

async function startCollector() {
  if (!document.body) return;
  const provider = await resolveProvider();
  if (!provider) {
    detachObserver();
    return;
  }
  if (await syncCollectorForPage()) {
    scheduleSend();
    scheduleCursorRetries(provider);
    scheduleDevinRetries();
  }
}

function onNavigation() {
  void startCollector();
}

try {
  chrome.runtime?.onMessage?.addListener((message) => {
    if (message?.type === "AI_USAGE_COLLECT_NOW") {
      void startCollector();
    }
  });
} catch (error) {
  if (!isContextInvalidatedError(error)) throw error;
}

try {
  chrome.storage?.onChanged?.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.devinOrgSlug) return;
    void startCollector();
  });
} catch (error) {
  if (!isContextInvalidatedError(error)) throw error;
}
window.addEventListener("popstate", onNavigation);
window.addEventListener("hashchange", onNavigation);

if (document.body) void startCollector();
else document.addEventListener("DOMContentLoaded", () => void startCollector(), { once: true });
